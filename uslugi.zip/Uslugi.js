import React from 'react';
import { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { set } from 'react-hook-form';
import './uslugi.css';
import wyslij from './obrazy/wyslij.png';
import axios from 'axios';
import star5 from './obrazy/5.gif';
import star4 from './obrazy/4.gif';
import star3 from './obrazy/3.gif';
import star2 from './obrazy/2.gif';
import star1 from './obrazy/1.gif';

const Uslugi = () =>{

  const [rate, setrate] = useState()

  const postData = (e) => {
    e.preventDefault();
    axios.post('https://localhost:44328/surveys', {
          rate
    }).then(res => console.log(res)).catch(err => console.log(err))
  }

  return (
    <div className="banner">
      <div className="containerrate">
        
        <form>
          <p>Jak oceniasz nasze usługi w skali 1-5?</p>
          <div class="rating-type">
            <div class="rating-containter">
              <div class="rating-block animated-smileys">
            <label>
              <input type="radio" id="Rate" name="ocen" onChange={() => setrate('star5')} defaultValue="star5" /> 
              <div>
                <img src={star5}></img>
              </div>
            </label>
            <label><input type="radio" id="Rate" name="ocen" onChange={() => setrate('star4')} defaultValue="star4" /> 
            
              <div>
                <img src={star4}></img>
              </div>
            </label>
            <label><input type="radio" id="Rate" name="ocen" onChange={() => setrate('star3')} defaultValue="star3" /> 
            
              <div>
                <img src={star3}></img>
              </div>
            </label>
            <label><input type="radio" id="Rate" name="ocen" onChange={() => setrate('star2')} defaultValue="star2" /> 
            
              <div>
                <img src={star2}></img>
              </div>
            </label>
            <label><input type="radio" id="Rate" name="ocen" onChange={() => setrate('star1')} defaultValue="star1" /> 
            
              <div>
                <img src={star1}></img>
              </div>
            </label>
          </div>
          </div>
                  </div>
                  <div class="rating-type">
                      <p>Podziel się swoją opinią na nasz temat!</p>
                      <textarea id="opinia" name="opinia" rows={5} cols={55} placeholder=" Miejsce na wpisanie odpowiedzi..." defaultValue={""} />
                  </div>
          <button type="submit" className="submit-btn"><img className="wyslij" src={wyslij} width={70} height={50} /></button>
        </form>
      </div>
    </div>
  )
}

export default Uslugi;
