import React, { useState } from "react";
import Glowna from "./Glowna.js";


import "./panel.css";

function Panel(){
  const [errorMessages, setErrorMessages] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const database = [
    {
      username: "admin",
      password: "admin"
    }
  ];

  const errors = {
    uname: <h13>Użytkownik o takim adresie e-mail nie istnieje</h13>,
    pass: <h13>Podane hasło jest nieprawidłowe</h13>
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    var {uname, pass} = document.forms[0];

    const userData = database.find((user) => user.username === uname.value);

    if (userData) {
      if (userData.password !== pass.value) {
        // Invalid password
        setErrorMessages({ name: "pass", message: errors.pass });
      } else {
        setIsSubmitted(true);
        }
      } else {
        // Username not found
        setErrorMessages({ name: "uname", message: errors.uname });
      }
    };

    const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

    const renderForm = (
      <div class="bannerlogin">
        <div class="containerlogin">
          <div class="cv1">
            <div class="napislogin">
              <h9>Zaloguj się</h9>
            </div>
            <div className="formlogin">
              <form onSubmit={handleSubmit}>
                <div className="input-container">
                  <label>E-mail: </label>
                  <input type="text" name="uname" required />
                  {renderErrorMessage("uname")}
                </div>
                <div className="input-container">
                  <label>Hasło: </label>
                  <input type="password" name="pass" required />
                  {renderErrorMessage("pass")}
                </div>
                <center>
                <a class="alogin" href="forgot">Zapomniałeś hasła?</a></center>
                <div className="button-conteiner">
                <input type="submit" class="loginsubmit" value="Zaloguj się"/>
                </div>
              </form>
            </div>
          </div>
          <div className="cv2">
            <div class="naglowki">
              <h10>Chcesz dopasować do siebie<br /></h10>
              <h11>CIASTECZKO?</h11>
              <h12>Zaloguj się i wypełnij naszą ankietę</h12>
            </div>
          </div>
        </div>
      </div>
    );

    return (
      <div className="panel">
        <div className="login-form">
          <div className="title">Zaloguj się</div>
          {isSubmitted ? Glowna(): renderForm}
        </div>
      </div>
    );
  }
export default Panel;